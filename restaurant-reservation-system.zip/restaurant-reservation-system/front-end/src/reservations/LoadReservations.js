import React, {useState} from "react";
import { updateReservationStatus } from "../utils/api";
import {Link} from "react-router-dom"; 
import ErrorAlert from "../layout/ErrorAlert";