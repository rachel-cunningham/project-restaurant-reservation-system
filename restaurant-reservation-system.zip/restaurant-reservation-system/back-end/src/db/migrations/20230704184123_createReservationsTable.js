exports.up = function (knex) {
  return knex.schema.createTable("reservations", (table) => {
    table.increments("reservation_id").primary();
    table.integer("table_id");
    table
      .foreign("table_id")
      .references("table_id")
      .inTable("tables")
      .onDelete("cascade");
    table.string("first_name").notNullable();
    table.string("last_name").notNullable();
    table.string("mobile_number").notNullable();
    table.date("reservation_date").notNullable();
    table.time("reservation_time").notNullable();
    table.integer("people").notNullable();
    table.timestamps(true, true);
  });
};
exports.down = function (knex) {
  return knex.schema.dropTable("reservations");
};
